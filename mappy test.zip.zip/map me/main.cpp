/////////////////////////////////////////////////////////
// Game Programming All In One, Third Edition
// Chapter 16 - PlatformScroller
/////////////////////////////////////////////////////////

#include <stdio.h>
#include <allegro.h>
#include "mappyal.h"

#define MODE GFX_AUTODETECT_WINDOWED
#define WIDTH 320
#define HEIGHT 320
#define JUMPIT 64

BITMAP *buffer;	
BITMAP *temp;


/* Tile grabber. */
BITMAP *grabframe(BITMAP *source, 
                  int width, int height, 
                  int startx, int starty, 
                  int columns, int frame)
{
    BITMAP *temp = create_bitmap(width,height);
    int x = startx + (frame % columns) * width;
    int y = starty + (frame / columns) * height;
    blit(source,temp,x,y,0,0,width,height);
    return temp;
}


int collided(int x, int y)
{
    BLKSTR *blockdata;
	blockdata = MapGetBlock(x, y);
	return blockdata->tl;
}


class ball {
   int x, y;
   int fw, fh;
   int radius, spriteSize;
   BITMAP *bigBall;
   
   public : void init(int bx, int by, int w, int h)
   {
      /* Set bound position. */
      x = bx;
      y = by;
      
      /* Set initial size. */
      radius = 8;
      spriteSize = 32;
      
      /* Set environment bounds. */
      fw = w;
      fh = h;
      
      /* Make the ball and erase bitmaps. */
      bigBall = create_bitmap(spriteSize, spriteSize);
      
      /* Draw the ball. */
      clear_to_color(bigBall, makecol(255, 0, 255));
      circlefill(bigBall, spriteSize/2, spriteSize/2, radius, makecol(255, 0, 0));
      
   }
   
   public: void shutdown(void)
   {
      destroy_bitmap(bigBall);
   }
   
   public : void drawBall(BITMAP *b)
   {
      draw_sprite(b, bigBall, x*spriteSize, y*spriteSize);
   }
   
   public : void moveMe(char dir)
   {
      int tx, ty;
      
      tx = x;
      ty = y;
      
      /* Right. */
      if (dir == 1) {
         if (x < (fw - 1)) {
            x = x+1;
         }
      }
      /* Left. */
      else if (dir == -1) {
         if (x > 0) {
            x = x-1;
         }
      }
      /* Up. */
      if (dir == -2) {
         if (y > 0) {
            y = y-1;
         }
      }
      /* Down. */
      else if (dir == 2) {
         if (y < (fh - 1)) {
            y = y+1;
         }
      }
      
      if (collided(x, y)) {
         x = tx;
         y = ty;
      }
      
   } 
};




int main (void)
{
    int j, k;
    
    ball redBall;
    
    /* Init allegro. */
	allegro_init();	
	install_timer();
	install_keyboard();
	set_color_depth(32);
	set_gfx_mode(MODE, WIDTH, HEIGHT, 0, 0);


    //load the map
	MapLoad("mappy test.FMP");
	
	for(j=0;j<10;j++) {
       for(k=0;k<10;k++) {
          printf("%d ", collided(k, j));
       }
       printf("\n");
    }

    //create the double buffer
	buffer = create_bitmap (WIDTH, HEIGHT);
	clear(buffer);
	
	/* Init ball. */
	redBall.init(0, 0, 10, 10);

    //main loop
	while (!key[KEY_ESC])
	{

		

		if (key[KEY_RIGHT]) 
        { 
            printf("Key right! \n");  
            redBall.moveMe(1);
        }
        else if (key[KEY_LEFT]) 
        { 
            printf("Key left! \n");  
            redBall.moveMe(-1);
        }
        else if (key[KEY_UP]) 
        { 
            printf("Key up! \n");  
            redBall.moveMe(-2);
        }
        else if (key[KEY_DOWN]) 
        { 
            printf("Key down! \n");  
            redBall.moveMe(2);
        }

        //draw the background tiles
		MapDrawBG(buffer, 0, 0, 0, 0, WIDTH-1, HEIGHT-1);
		
		/* Draw the ball */
		redBall.drawBall(buffer);


        //blit the double buffer 
		vsync();
        acquire_screen();
		blit(buffer, screen, 0, 0, 0, 0, WIDTH-1, HEIGHT-1);
        release_screen();
        
        
        rest(50);

	} /* End while. */

 
    redBall.shutdown();

	destroy_bitmap(buffer);
	MapFreeMem ();
	allegro_exit();
	return 0;
}
END_OF_MAIN()
