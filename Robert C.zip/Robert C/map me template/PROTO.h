#include<allegro.h>

BITMAP *grabframe(BITMAP *source,int width, int height, int startx, int starty, int columns, int frame);

int anibeeskeeter(void);
int anidragon (char tf); 
char collided1 (void);
void circle (void);
void dragonfall (void);
void drawDragonScroll(BITMAP *b);
void move (void);
void sky (void);
char collide2(void);
void circle (void);
void level1A (void);
void fire (void);
char staticfall (void);
char dynamicbugfall(void);
